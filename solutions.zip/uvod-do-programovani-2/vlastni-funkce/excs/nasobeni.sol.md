---
title: Násobení
demand: 1
---

Napiš funkci `mult`, která bude mít dva číselné parametry. Funkce oba parametry vynásobí a vrátí výsledek.

:::solution
```py
def mult(a, b):
    return a * b
```
:::
