---
title: Rozpětí
demand: 2
---

Postupujte obdobně jako v úložce Průměr, ale tentokrát sestavte výraz pro výpočet **rozpětí**, tedy rozdílu mezi minimální a maximální hodnotou.

:::solution
```py
r = max(s)-min(s)
print(r)
```
:::
