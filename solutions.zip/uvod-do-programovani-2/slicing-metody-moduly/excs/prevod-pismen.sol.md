---
title: Převod písmen
demand: 1
---

Uložte si do proměnné `jmeno` svoje jméno. Pomocí volání vhodných metod jej
převeďte nejdříve na malá písmena a poté na velká písmena.

:::solution
```py
jmeno = "Martin Podloucký"
print(jmeno.lower())
print(jmeno.upper())
```
:::
